
NRC-Emotion-Lexicon-v0.92-InManyLanguages.xlsx is an older version of NRC-Emotion-Lexicon-v0.92-In105Languages-Nov2017Translations.xlsx.
NRC-Emotion-Lexicon-v0.92-InManyLanguages.xlsx includes translations into 40 languages. The translations were done using Google Translate in May 2015.
